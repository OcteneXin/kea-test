import html
from typing import Dict
from . import cfgs

class HTMLElementEncoder:
    
    TEMPLATE_MAPPING: Dict[str, str] = {
        "CHECKBOX": '<input id="{id}" type="checkbox" resource-id="{class_}" name="{class_}">\n<label for="{id}">{text}</label>\n',
        "CHECKEDTEXTVIEW": '<input id="{id}" type="checkbox" resource-id="{class_}" name="{class_}">\n<label for="{id}">{text}</label>\n',
        "SWITCH": '<input id="{id}" type="checkbox" resource-id="{class_}" name="{class_}">\n<label for="{id}">{text}</label>\n',
        "RADIOBUTTON": '<input id="{id}" type="radio" resource-id="{class_}" name="{class_}">\n<label for="{id}">{text}</label>\n',
        "SPINNER": '<label for="{id}">{text}</label>\n<select id="{id}" resource-id="{class_}" name="{class_}"></select>\n',
        "IMAGEVIEW": '<img id="{id}" resource-id="{class_}" {class_attr} alt="{content_desc}" />\n',
        "EDITTEXT": '<input id="{id}" resource-id="{class_}" {class_attr} placeholder="{text}" value="" />\n',
    }

    def element_encoding(self, _id: str, _obj_type: str, _text: str, _content_desc: str, _resource_id: str) -> str:
        _class = _resource_id.split('id/')[-1].strip()
        _text = html.escape(_text.strip())
        _content_desc = html.escape(_content_desc.strip())

        # 类名
        class_attr = f'class="{_class}"' if _class else ""

        # 确保 _obj_type 在映射中
        if _obj_type not in cfgs.CLASS_MAPPING:
            raise ValueError(f"Unsupported object type: {_obj_type}")

        
        # 获取 HTML 模板
        if _obj_type in self.TEMPLATE_MAPPING:
            
            return self.TEMPLATE_MAPPING[_obj_type].format(id=_id, class_=_class, text=_text, content_desc=_content_desc, class_attr=class_attr)

        # 处理默认情况
        tag = cfgs.CLASS_MAPPING[_obj_type]
        _text = _content_desc if not _text else _text
        class_attr = f' class="{_class}"' if _class else ""
        return f'  <{tag} id="{_id}"{class_attr}>{_text}</{tag}>\n'
