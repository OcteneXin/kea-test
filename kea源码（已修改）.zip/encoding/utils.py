def sortchildrenby_viewhierarchy(view, attr="bounds"):
    if attr == 'bounds':
        bounds = [(ele.uiobject.bounding_box.x1, ele.uiobject.bounding_box.y1, 
                    ele.uiobject.bounding_box.x2, ele.uiobject.bounding_box.y2)  
                    for ele in view]
        sorted_bound_index = [bounds.index(i) for i in sorted(bounds, key = lambda x: (x[1], x[0]))]
    
        sort_children = [view[i] for i in sorted_bound_index]
        view[:] = sort_children

def exclude_navigationbar(view):
    pass
    # for ele in view:
    #     print(ele.uiobject.resource_id)

    # view[:] = [element for element in view if "com.android.systemui:id" not in element.uiobject.resource_id]