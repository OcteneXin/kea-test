import logging
from . import view_hierarchy
from . import utils
from . import cfgs
from . import html_encoder
import html

class UI():
    def __init__(self, xml_content):
        self.logger = logging.getLogger(self.__class__.__name__)

        # html解析器
        self.encoder = html_encoder.HTMLElementEncoder()

        # 可操作元素列表
        self.elements = {}


        # 虚拟页面结构, 去除了状态栏、导航栏、键盘等
        vh = view_hierarchy.ViewHierarchy(
                    screen_width=cfgs.XML_SCREEN_WIDTH,
                    screen_height=cfgs.XML_SCREEN_HEIGHT)
        vh.load_xml(xml_content)
        leaves = vh.get_leaf_nodes() # 叶子节点
        utils.sortchildrenby_viewhierarchy(leaves, 'bounds') # 从上到下排序
        for _id, ele in enumerate(leaves):
            self.elements[_id] = ele.uiobject

   
    def is_form(self):
        """
        判断页面是否为表单
        @return: bool
        """
        btns = self.find_btns()
        return (sum(1 for _id, ui_obj in self.elements.items() if ui_obj.obj_type.name in cfgs.INPUT_TYPES) >=1) and len(btns)>=2
    

    def encode_btn(self, _obj_type: str, _text: str, _content_desc: str, _resource_id: str):
        if(_obj_type != 'BUTTON' and _obj_type != 'TEXTVIEW'): return False

        _class = _resource_id.split('id/')[-1].strip()
        _text = html.escape(_text.strip())
        _content_desc = html.escape(_content_desc.strip())

        # btn_text = (_class+' '+_text+' '+_content_desc).lower()
        btn_text = _text.lower()
        print(btn_text)

        possible_positive_btn_str=['yes','apply','allow','ok','submit','save','commit','confirm','create','delete']
        possible_negative_btn_str=['no','cancel','deny']
        
        for t in possible_positive_btn_str:
            if btn_text==t: return 'positive'

        for t in possible_negative_btn_str:
            if btn_text==t: return 'negative'

        return False
    
    def find_btns(self):
        """
        找按钮（正面或负面）
        @return: view
        """
        # 所有按钮列表
        possible_btns = []
        for _id, ui_obj in self.elements.items():
            btn_type = self.encode_btn(
                ui_obj.obj_type.name, 
                ui_obj.text.replace('\n', ' '), 
                ui_obj.content_desc,
                ui_obj.resource_id)
            
            if(btn_type): possible_btns.append({'id': _id, 'resource_id': ui_obj.resource_id.split('id/')[-1].strip(),  'btn_type': btn_type})


        self.logger.info('Encoded btn\n')
        self.logger.info(possible_btns)
        return possible_btns
    

    def to_html(self):
        """
        将当前UI转换为HTML格式
        @return: str
        """
        # 所有html片段列表
        html_codes = [
            self.encoder.element_encoding(
                _id, 
                ui_obj.obj_type.name, 
                ui_obj.text.replace('\n', ' '), 
                ui_obj.content_desc, 
                ui_obj.resource_id
            ) 
            for _id, ui_obj in self.elements.items()
        ]

        # 列表拼接
        codes = "<html>\n" + "".join(html_codes) + "</html>"

        self.logger.info('Encoded UI\n' + codes)
        return codes
    
    def get_element_view(self, _id, _resource_id):

        target_elem = None

        # 优先用resource_id定位
        if(_resource_id is not None):
            for _id, ui_obj in self.elements.items():
                temp_id = ui_obj.resource_id.split('id/')[-1].strip()
                if(temp_id==_resource_id) : 
                    target_elem = ui_obj
                    break

        # 如果没有resource_id只能用序号定位
        if(target_elem is None):
            target_elem = self.elements[_id]

        bbox = target_elem.bounding_box
        return {"bounds": [[bbox.x1,bbox.y1],[bbox.x2,bbox.y2]],"class":"default","view_str":"default"}
