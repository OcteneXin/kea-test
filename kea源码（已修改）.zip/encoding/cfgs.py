from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

# Android Emulator Config
SCREEN_WIDTH = 1080
SCREEN_HEIGHT = 1920
SCREEN_CHANNEL = 4
SCREEN_TOP_HEAD = 63
SCREEN_BOTTOM_HEAD = 126
# screen config
ADJACENT_BOUNDING_BOX_THRESHOLD = 3
NORM_VERTICAL_NEIGHBOR_MARGIN = 0.01
NORM_HORIZONTAL_NEIGHBOR_MARGIN = 0.01
INPUT_ACTION_UPSAMPLE_RATIO = 1
# XML screen config
XML_SCREEN_WIDTH = 1440
XML_SCREEN_HEIGHT = 2960

# CHATGPT CONFIGURATIONS
OPENAI_TOKEN = ""
MODEL = "gpt-3.5-turbo"
TEMPERATURE = 0.2
# MAX_TOKENS = 1000
FREQUENCY_PENALTY = 0.0
PRESENCE_PENALTY = 0.0
INITIAL_SYSTEM_PROMPT = "You are a senior bug report expert."
INITIAL_USER_PROMPT = "Please remember your duty is to understand the bug report and identifying the steps to reproduce the issue."
# PROMPT CONFIGURATIONS
ACTION_LISTS = ['tap', 'double tap', 'input', 'scroll', 'long tap']
RANDOM_INPUT_TEXT = "test"
# UI ENCODING CONFIGURATIONS
CLASS_MAPPING = {
    'TEXTVIEW': 'p',
    'BUTTON': 'button',
    'IMAGEBUTTON': 'button',
    'IMAGEVIEW': 'img',
    'EDITTEXT': 'input',
    'CHECKBOX': 'input',
    'CHECKEDTEXTVIEW': 'input',
    'TOGGLEBUTTON': 'button',
    'RADIOBUTTON': 'input',
    'SPINNER': 'select',
    'SWITCH': 'input',
    'SLIDINGDRAWER': 'input',
    'TABWIDGET': 'div',
    'VIDEOVIEW': 'video',
    'SEARCHVIEW': 'div'
}

# 属于输入框的类型，同一页面上>2个认为是表单
# INPUT_TYPES={
#     "CHECKBOX",
#     "CHECKEDTEXTVIEW", 
#     "SWITCH", 
#     "EDITTEXT",
#     "RADIOBUTTON",
#     "SLIDINGDRAWER"
# }

INPUT_TYPES={
    "EDITTEXT"
}