import logging

class TarpitDetector():
    def __init__(self, __input_manager):
        self.input_manager = __input_manager
        self.same_page_count = 0
        self.stay_threshold = 15
        self.restart_threshold_ = 30
        self.last_activity = ""

    def get_tarpit_type(self,ui_tree,llm_event_cooldown):

        self.update_activity()

        # permission Activity
        if(self.is_permission()): return "permission"

        # system Activity
        if(self.is_system()): return "system"

        # form
        if(self.detect_form(ui_tree)):
            if(llm_event_cooldown): return "form-cooldown"
            else: return "form"

        # model
        if(self.detect_keywords(ui_tree)): return "model"


        # # restart
        # if(self.is_stay_same_page_too_long_2()):
        #     return "restart"

        # stuck pages
        if(self.is_stay_same_page_too_long()):
            return "stuck"
        


        return False
    
    def is_permission(self):
        current_activity = self.input_manager.device.get_current_state().foreground_activity

        return current_activity.endswith('GrantPermissionsActivity') 
    
    
    def is_system(self):
        current_activity = self.input_manager.device.get_current_state().foreground_activity

        package_name = current_activity.split('.')[1]

        return (package_name=='google' or package_name=='android') and (not current_activity.endswith('NexusLauncherActivity'))
    
    # 模态框
    def detect_keywords(self,ui_tree):
        btns = ui_tree.find_btns()

        has_positive = False
        has_negative = False

        for btn in btns:
            if(btn['btn_type']=='positive'): has_positive = True
            else: has_negative = True
                    
        return has_positive and has_negative
    
    # >=2 按钮 && >=1 输入框
    def detect_form(self,ui_tree):
        return ui_tree.is_form()
    
    # 更新
    def update_activity(self):
        current_activity = self.input_manager.device.get_current_state().foreground_activity
        print(self.last_activity,current_activity)

        if(self.last_activity==current_activity): self.same_page_count+=1
        else: self.same_page_count=0

        self.last_activity = current_activity # update

    # 卡住：第一阶段
    def is_stay_same_page_too_long(self):
        current_activity = self.input_manager.device.get_current_state().foreground_activity

        # return (not current_activity.endswith('MainActivity')) and self.same_page_count >= self.stay_threshold
        if(self.same_page_count >= self.stay_threshold):
            self.same_page_count = 0
            return True
        return False
    
    
    # 卡住：第二阶段
    def is_stay_same_page_too_long_2(self):
        return self.same_page_count >= self.restart_threshold_