from encoding import ui



with open("C:\\Users\\HP\\Desktop\\kea\\ecnusse\\Kea\\kea\\test3.xml", 'r') as f:
    str = f.read().encode('utf-8')

html = ui.UI(str).to_html()

print(html)