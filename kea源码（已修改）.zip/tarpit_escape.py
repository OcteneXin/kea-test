import logging
import random
import json
from .encoding import ui
from .llm import chat

class TarpitEscape():
    def __init__(self, __input_manager):
        self.input_manager = __input_manager

    @staticmethod
    def __safe_dict_get(view_dict, key, default=None):
        '''
        防keyError的
        '''
        value = view_dict[key] if key in view_dict else None
        return value if value is not None else default

    def selectStrategy(self, input_manager, ui_tree, type):

        event_list = []

        # 授权一般选正面按钮
        if(type=="permission"):
            btns = ui_tree.find_btns()
            print(btns)
            for btn in btns:
                if(btn['btn_type']=='positive'):
                    event_list = [
                        {
                            "id": btn['id'],
                            "resource_id":  btn['resource_id'],
                            "event": "click"
                        }
                    ]
                    break
        # 其他页面一般返回
        elif(type=="system"): 
            event_list = [
                        {
                            "event": "back"
                        }
                    ]
        # 模态框（单选）随机选一个按钮点击，有20%概率不点击
        elif(type=="model"):
            btns = ui_tree.find_btns()
            if(random.random()<0.8):
                btn = random.choices(btns)[0]
                event_list = [
                        {
                            "id": btn['id'],
                            "resource_id":  btn['resource_id'],
                            "event": "click"
                        }
                    ]
        # 表单（>=2 按钮 && >=1 输入框）
        elif(type=="form"): # 可以用大模型
            print("*********form********")
            res = chat.query_llm(ui_tree.to_html())
            event_list = json.loads(res)["operations"] # 产生新的llm序列
        # 目前llm还在冷却
        elif(type=="form-cooldown"):
            print("cd")
            # 尝试随便按一个按钮
            btns = ui_tree.find_btns()
            btn = random.choices(btns)[0]
            event_list = [
                    {
                        "id": btn['id'],
                        "resource_id":  btn['resource_id'],
                        "event": "click"
                    }
                ]

        # 卡住时优先返回
        elif(type=="stuck"):
            event_list = [
                        {
                            "event": "back"
                        }
                    ]
        
        # 返回都解决不了
        elif(type=="restart"):
            event_list = [
                        {
                            "event": "restart"
                        }
                    ]
            

        logging.info(event_list)
        return event_list
    