from zhipuai import ZhipuAI

client = ZhipuAI(api_key="1ce536893fe64977b65e4718f26a77a0.0Tcd2iu4FU4gGUHv")  # 请填写您自己的APIKey
