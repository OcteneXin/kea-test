from . import model
from . import prompts

def query_llm(html):
    user_prompt = prompts.fill_out_form_prompt.replace("<form_content>", html)
    print(user_prompt)

    response = model.client.chat.completions.create(
        model="glm-4-plus",  # 请填写您要调用的模型名称
        messages=[
            {"role": "system", "content": """您是一个帮助用户填写表单的助手。请根据指令使用指定的JSON对象结构，确保只返回JSON字符串，不要返回任何其他内容。"""},
            {"role": "user", "content": user_prompt},
        ],
        temperature=1.0,
        response_format = {
            'type': 'json_object'
        },
    )
    res1 = response.choices[0].message.content.replace('\n', '').replace('\t', '')
    print(res1)

    res = """{
            "operations": [
                {
                "id": 2,
                "event": "input",
                "text": "new_secure_password"
                },
                {
                "id": 3,
                "event": "input",
                "text": "new_secure_password"
                },
                {
                "id": 5,
                "event": "input",
                "text": "What is your mother's maiden name?"
                },
                {
                "id": 6,
                "event": "input",
                "text": "Smith"
                },
                {
                "id": 7,
                "event": "input",
                "text": "Smith"
                },
                {
                "id": 10,
                "event": "click"
                }
            ]
        }"""
    
    return res1

