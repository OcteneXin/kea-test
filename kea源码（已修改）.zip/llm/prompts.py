json_response_format = """
{
	"operations":[
		{
			"id": 1,
            "resource_id" : "username"
			"event": "input",
			"text": "admin"
		},
		{
			"id": 2,
            "resource_id" : "password"
			"event": "input",
			"text": "123456"
		},
		{
			"id": 7,
            "resource_id" : "button2"
			"event": "click"
		}
	]
}
"""

fill_out_form_prompt = f"""
I encountered a form when I use an App. The form will be given in HTML format. Please generate a list of operations to fill out this form. Your answer should be JSON format, like this:
{json_response_format}

The form is:
<form_content>
"""
